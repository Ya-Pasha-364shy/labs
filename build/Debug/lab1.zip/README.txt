Run: ./lab1 example.txt
